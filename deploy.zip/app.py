import os
from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, Team, UserTeam, StyleRule, Project, Manuscript, ErrorRecord
from qc_engine import run_qc_engine, apply_change
import tempfile
import mammoth

app = Flask(__name__)
app.config['SECRET_KEY'] = 'super-secret-manuscript-key-123'
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'qc_platform.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

# Initialize database
def init_db():
    with app.app_context():
        # Only create if it doesn't exist
        db.create_all()
        if not User.query.filter_by(email='admin@qcplatform.com').first():
            admin = User(name='Admin User', email='admin@qcplatform.com', password_hash=generate_password_hash('password123'), role='admin')
            db.session.add(admin)
            team = Team(name='Default Journal', description='Primary journal editing team')
            db.session.add(team)
            db.session.commit()
            db.session.add(UserTeam(user_id=admin.id, team_id=team.id))
            db.session.add(StyleRule(team_id=team.id, name='Figure Abbreviation', category='Style', find_pattern='Figure', replacement='Fig.'))
            db.session.add(StyleRule(team_id=team.id, name='Table Abbreviation', category='Style', find_pattern='Table', replacement='Tab.'))
            db.session.commit()
init_db()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form.get('email')).first()
        if user and check_password_hash(user.password_hash, request.form.get('password')):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid credentials', 'error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    projects = Project.query.join(Team).join(UserTeam).filter(UserTeam.user_id == current_user.id).all()
    total_projects = len(projects)
    pending_qc = len([p for p in projects if p.status != 'Finalized'])
    completed = len([p for p in projects if p.status == 'Finalized'])
    
    # Calculate critical errors pending across all projects
    critical_errors = ErrorRecord.query.join(Manuscript).join(Project).join(Team).join(UserTeam)\
        .filter(UserTeam.user_id == current_user.id, ErrorRecord.status == 'PENDING', ErrorRecord.category == 'Critical').count()
        
    return render_template('dashboard.html', projects=projects, total=total_projects, pending=pending_qc, critical=critical_errors, completed=completed)

@app.route('/projects', methods=['GET'])
@login_required
def projects():
    all_projects = Project.query.join(Team).join(UserTeam).filter(UserTeam.user_id == current_user.id).all()
    return render_template('projects.html', projects=all_projects)

@app.route('/projects/new', methods=['GET', 'POST'])
@login_required
def new_project():
    teams = current_user.teams
    if request.method == 'POST':
        name = request.form.get('name')
        team_id = request.form.get('team_id')
        
        # Helper to extract text
        def extract_text(file_obj):
            if not file_obj or file_obj.filename == '':
                return None
            fname = file_obj.filename.lower()
            try:
                if fname.endswith('.docx') or fname.endswith('.doc'):
                    return mammoth.extract_raw_text(file_obj).value
                elif fname.endswith('.xml') or fname.endswith('.txt'):
                    return file_obj.read().decode('utf-8', errors='ignore')
            except Exception as e:
                pass
            return None

        # Handle file upload
        file = request.files.get('manuscript_file')
        if not file or file.filename == '':
            flash('No author file selected', 'error')
            return redirect(request.url)
            
        author_text = extract_text(file)
        if author_text is None:
            flash('Unsupported file type or error reading author file. Use DOCX, XML, or TXT.', 'error')
            return redirect(request.url)

        my_file = request.files.get('xml_file')
        my_text = extract_text(my_file)

        project = Project(name=name, team_id=team_id)
        db.session.add(project)
        db.session.commit()
        
        manuscript = Manuscript(project_id=project.id, original_text=author_text, working_text=my_text if my_text else author_text)
        db.session.add(manuscript)
        db.session.commit()
        
        team_rules = StyleRule.query.filter_by(team_id=team_id, is_active=True).all()
        errors = run_qc_engine(manuscript, team_rules)

        # Diff engine if second file is provided
        if my_text and my_text != author_text:
            import difflib
            matcher = difflib.SequenceMatcher(None, author_text, my_text)
            for tag, i1, i2, j1, j2 in matcher.get_opcodes():
                if tag in ('replace', 'delete', 'insert'):
                    found = author_text[i1:i2]
                    expected = my_text[j1:j2]
                    # Only flag meaningful differences
                    if found.strip() or expected.strip():
                        errors.append({
                            'rule_id': None,
                            'category': 'Manual Edit' if tag == 'replace' else ('Missing Content' if tag == 'delete' else 'Added Content'),
                            'found_text': (found[:250] + '...') if len(found)>250 else (found if found else '[Missing]'),
                            'expected_text': (expected[:250] + '...') if len(expected)>250 else (expected if expected else '[Deleted]'),
                            'location_index': i1
                        })
        
        for e in errors:
            db.session.add(ErrorRecord(manuscript_id=manuscript.id, rule_id=e.get('rule_id'), category=e['category'], found_text=e['found_text'], expected_text=e['expected_text'], location_index=e['location_index']))
            
        manuscript.status = 'QC Complete'
        db.session.commit()
        flash('Project created and QC completed.', 'success')
        return redirect(url_for('review_project', project_id=project.id))
    return render_template('new_project.html', teams=teams)

@app.route('/projects/<int:project_id>/review')
@login_required
def review_project(project_id):
    project = db.session.get(Project, project_id)
    manuscript = project.manuscripts[0]
    errors = ErrorRecord.query.filter_by(manuscript_id=manuscript.id, status='PENDING').all()
    total_errors = ErrorRecord.query.filter_by(manuscript_id=manuscript.id).count()
    resolved_errors = total_errors - len(errors)
    progress = int((resolved_errors / total_errors) * 100) if total_errors > 0 else 100
    return render_template('review.html', project=project, manuscript=manuscript, errors=errors, progress=progress)

@app.route('/errors/<int:error_id>/action', methods=['POST'])
@login_required
def resolve_error(error_id):
    error = db.session.get(ErrorRecord, error_id)
    action = request.form.get('action')
    if action == 'CHANGE':
        apply_change(error.manuscript, error)
        error.status = 'CHANGED'
    else:
        error.status = 'IGNORED'
    db.session.commit()
    return redirect(url_for('review_project', project_id=error.manuscript.project.id))

@app.route('/projects/<int:project_id>/finalize', methods=['POST'])
@login_required
def finalize_project(project_id):
    project = db.session.get(Project, project_id)
    project.status = 'Finalized'
    db.session.commit()
    flash('Project finalized successfully.', 'success')
    return redirect(url_for('review_project', project_id=project.id))

@app.route('/projects/<int:project_id>/download', methods=['GET'])
@login_required
def download_project(project_id):
    project = db.session.get(Project, project_id)
    manuscript = project.manuscripts[0]
    
    # Create a temporary file to send to the user
    fd, path = tempfile.mkstemp(suffix='.txt')
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        f.write(manuscript.working_text)
        
    return send_file(path, as_attachment=True, download_name=f"{project.name}_final.txt")

@app.route('/projects/<int:project_id>/skip_all', methods=['POST'])
@login_required
def skip_all_errors(project_id):
    project = db.session.get(Project, project_id)
    if not project:
        return redirect(url_for('projects'))
    manuscript = project.manuscripts[0] if project.manuscripts else None
    if manuscript:
        errors = ErrorRecord.query.filter_by(manuscript_id=manuscript.id, status='PENDING').all()
        for e in errors:
            e.status = 'IGNORED'
        db.session.commit()
        flash('All remaining errors were skipped.', 'info')
    return redirect(url_for('review_project', project_id=project.id))

@app.route('/projects/<int:project_id>/delete', methods=['POST'])
@login_required
def delete_project(project_id):
    project = db.session.get(Project, project_id)
    if project:
        for ms in project.manuscripts:
            ErrorRecord.query.filter_by(manuscript_id=ms.id).delete()
            db.session.delete(ms)
        db.session.delete(project)
        db.session.commit()
    return redirect(url_for('projects'))
# --- ADMIN ROUTES ---
@app.route('/admin/teams', methods=['GET', 'POST'])
@login_required
def admin_teams():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        name = request.form.get('name')
        desc = request.form.get('description')
        if name:
            new_team = Team(name=name, description=desc)
            db.session.add(new_team)
            db.session.commit()
            flash('Team created.', 'success')
            return redirect(url_for('admin_teams'))
            
    teams = Team.query.all()
    return render_template('admin_teams.html', teams=teams)

@app.route('/admin/rules', methods=['GET', 'POST'])
@login_required
def admin_rules():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        db.session.add(StyleRule(
            team_id=request.form.get('team_id'),
            name=request.form.get('name'),
            category=request.form.get('category'),
            find_pattern=request.form.get('find_pattern'),
            replacement=request.form.get('replacement')
        ))
        db.session.commit()
        flash('Rule added.', 'success')
        return redirect(url_for('admin_rules'))
        
    teams = Team.query.all()
    rules = StyleRule.query.all()
    return render_template('admin_rules.html', teams=teams, rules=rules)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
