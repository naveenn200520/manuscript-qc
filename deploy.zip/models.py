from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(50), nullable=False, default='staff') 
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    teams = db.relationship('Team', secondary='user_teams', backref=db.backref('members', lazy='dynamic'))

class Team(db.Model):
    __tablename__ = 'teams'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class UserTeam(db.Model):
    __tablename__ = 'user_teams'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id'), nullable=False)

class StyleRule(db.Model):
    __tablename__ = 'style_rules'
    id = db.Column(db.Integer, primary_key=True)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id'), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    category = db.Column(db.String(50), nullable=False) # Style, Language, Formatting, Critical
    find_pattern = db.Column(db.String(255), nullable=False)
    replacement = db.Column(db.String(255), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Project(db.Model):
    __tablename__ = 'projects'
    id = db.Column(db.Integer, primary_key=True)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id'), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(50), default='Pending QC')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    team = db.relationship('Team', backref=db.backref('projects', lazy=True))
    manuscripts = db.relationship('Manuscript', backref='project', lazy=True)

class Manuscript(db.Model):
    __tablename__ = 'manuscripts'
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    original_text = db.Column(db.Text, nullable=False)
    working_text = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(50), default='Uploaded')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    errors = db.relationship('ErrorRecord', backref='manuscript', lazy=True)

class ErrorRecord(db.Model):
    __tablename__ = 'error_records'
    id = db.Column(db.Integer, primary_key=True)
    manuscript_id = db.Column(db.Integer, db.ForeignKey('manuscripts.id'), nullable=False)
    rule_id = db.Column(db.Integer, db.ForeignKey('style_rules.id'), nullable=True)
    category = db.Column(db.String(50), nullable=False)
    found_text = db.Column(db.String(255), nullable=False)
    expected_text = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(50), default='PENDING') # PENDING, CHANGED, IGNORED
    location_index = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
