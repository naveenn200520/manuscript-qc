import re

def run_qc_engine(manuscript, style_rules):
    """
    Simulates the QC engine parsing text, matching regex rules,
    and returning a list of ErrorRecord dicts.
    """
    text = manuscript.working_text
    errors = []
    
    for rule in style_rules:
        if not rule.is_active:
            continue
            
        # Compile a regex to find exact matches of the find_pattern
        # We use word boundaries \b to ensure we don't match substrings inside words
        try:
            pattern = re.compile(rf'\b({re.escape(rule.find_pattern)})\b')
        except:
            # Fallback for simple string replacement if regex fails
            pattern = re.compile(re.escape(rule.find_pattern))
            
        for match in pattern.finditer(text):
            found_text = match.group(1)
            # Only flag if the replacement is actually different 
            # (e.g. if expected is "Fig." but text is "Figure")
            if found_text != rule.replacement:
                errors.append({
                    'rule_id': rule.id,
                    'category': rule.category,
                    'found_text': found_text,
                    'expected_text': rule.replacement,
                    'location_index': match.start()
                })
                
    return errors

def apply_change(manuscript, error):
    """
    Applies a change to the working text of a manuscript.
    Since replacing text shifts the index for subsequent errors,
    we do a simple string replace for this MVP. 
    In production, this requires an AST or XML node update.
    """
    text = manuscript.working_text
    # Simple replace for exact match (this handles the MVP nicely)
    # We replace the first occurrence after the location index (roughly)
    manuscript.working_text = text.replace(error.found_text, error.expected_text, 1)
    return True
